import React from 'react';
import { ArrowDown, Sparkles, Code2, Smartphone, Terminal, ArrowRight, ExternalLink } from 'lucide-react';
import { PERSONAL_INFO, FEATURED_PROJECT } from '../data/portfolioData';

export const HeroSection: React.FC = () => {
  const scrollTo = (id: string) => {
    const el = document.querySelector(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="home"
      className="relative pt-28 pb-16 sm:pt-36 sm:pb-24 lg:pt-40 lg:pb-32 overflow-hidden border-b border-slate-200/80 dark:border-slate-800/80"
    >
      {/* Subtle Background Glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[340px] sm:w-[600px] h-[340px] sm:h-[600px] bg-sky-500/10 dark:bg-sky-500/15 blur-3xl rounded-full pointer-events-none -z-10" />
      <div className="absolute top-1/3 right-10 w-[240px] sm:w-[400px] h-[240px] sm:h-[400px] bg-indigo-500/10 dark:bg-indigo-500/15 blur-3xl rounded-full pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          {/* Main Hero Content */}
          <div className="lg:col-span-7 flex flex-col items-start text-left">
            {/* Status Badge */}
            <div
              id="hero-status-badge"
              className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-500/10 dark:bg-emerald-500/15 text-emerald-700 dark:text-emerald-300 border border-emerald-500/20 text-xs sm:text-sm font-semibold tracking-wide mb-5 shadow-xs"
            >
              <span className="relative flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
              </span>
              <span>{PERSONAL_INFO.badge}</span>
            </div>

            {/* Main Greeting and Name */}
            <h1
              id="hero-main-heading"
              className="text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 dark:text-white leading-[1.15] mb-4"
            >
              Hi, I'm{' '}
              <span className="bg-gradient-to-r from-sky-600 via-indigo-600 to-sky-500 dark:from-sky-400 dark:via-indigo-300 dark:to-cyan-400 bg-clip-text text-transparent">
                {PERSONAL_INFO.name}
              </span>
            </h1>

            {/* Subtitle */}
            <div className="inline-block mb-4">
              <span
                id="hero-subtitle"
                className="text-lg sm:text-2xl font-bold text-slate-700 dark:text-slate-200 tracking-tight"
              >
                {PERSONAL_INFO.title}
              </span>
            </div>

            {/* Supporting Text */}
            <p
              id="hero-description"
              className="text-base sm:text-lg text-slate-600 dark:text-slate-300 max-w-2xl leading-relaxed mb-8"
            >
              {PERSONAL_INFO.heroDescription}
            </p>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-3.5 w-full sm:w-auto mb-8">
              <button
                id="hero-view-work-btn"
                onClick={() => scrollTo('#projects')}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-semibold text-sm shadow-md shadow-sky-600/25 hover:shadow-lg transition-all focus:outline-none focus:ring-2 focus:ring-sky-500"
              >
                <span>View My Work</span>
                <ArrowDown className="w-4 h-4" />
              </button>

              <button
                id="hero-contact-me-btn"
                onClick={() => scrollTo('#contact')}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-white dark:bg-slate-800/80 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-800 dark:text-slate-100 font-semibold text-sm border border-slate-200 dark:border-slate-700/80 shadow-xs transition-all focus:outline-none focus:ring-2 focus:ring-sky-500"
              >
                <span>Contact Me</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {/* Transparent Credentials Chips */}
            <div className="flex flex-wrap items-center gap-2 pt-2 text-xs text-slate-500 dark:text-slate-400">
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 font-medium">
                <Code2 className="w-3.5 h-3.5 text-sky-500" />
                HTML • CSS • Python
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 font-medium">
                <Smartphone className="w-3.5 h-3.5 text-emerald-500" />
                Mobile-First Focus
              </span>
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-slate-800/80 border border-slate-200/80 dark:border-slate-700/80 font-medium">
                <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
                AI-Assisted Workflow
              </span>
            </div>
          </div>

          {/* Right Column: Interactive Profile Card / Modern Code Terminal Card */}
          <div className="lg:col-span-5 w-full">
            <div
              id="hero-interactive-card"
              className="relative rounded-2xl bg-gradient-to-b from-white to-slate-50 dark:from-slate-900 dark:to-slate-950 p-5 sm:p-6 border border-slate-200 dark:border-slate-800 shadow-xl"
            >
              {/* Card Window Header */}
              <div className="flex items-center justify-between pb-4 mb-4 border-b border-slate-200 dark:border-slate-800">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-rose-500/80" />
                  <div className="w-3 h-3 rounded-full bg-amber-500/80" />
                  <div className="w-3 h-3 rounded-full bg-emerald-500/80" />
                  <span className="text-xs font-mono text-slate-500 dark:text-slate-400 ml-2">
                    developer.divij.ts
                  </span>
                </div>
                <div className="flex items-center gap-1 text-[11px] font-mono text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60 px-2 py-0.5 rounded-md border border-emerald-200 dark:border-emerald-800/60">
                  <Terminal className="w-3 h-3" />
                  <span>Ready</span>
                </div>
              </div>

              {/* Developer Snapshot Profile in Code Style */}
              <div className="space-y-3 font-mono text-xs sm:text-[13px]">
                <div className="text-slate-500 dark:text-slate-500">
                  <span className="text-sky-500 dark:text-sky-400">const</span> developer = &#123;
                </div>
                <div className="pl-4 space-y-1.5 text-slate-700 dark:text-slate-300">
                  <div>
                    <span className="text-slate-500">name:</span>{' '}
                    <span className="text-emerald-600 dark:text-emerald-400">'{PERSONAL_INFO.name}'</span>,
                  </div>
                  <div>
                    <span className="text-slate-500">education:</span>{' '}
                    <span className="text-amber-600 dark:text-amber-300">'10th Pass (Student)'</span>,
                  </div>
                  <div>
                    <span className="text-slate-500">role:</span>{' '}
                    <span className="text-emerald-600 dark:text-emerald-400">'Aspiring Web Developer'</span>,
                  </div>
                  <div>
                    <span className="text-slate-500">skillsStudied:</span> [
                    <span className="text-sky-600 dark:text-sky-300">'HTML'</span>,{' '}
                    <span className="text-sky-600 dark:text-sky-300">'CSS'</span>,{' '}
                    <span className="text-sky-600 dark:text-sky-300">'Python'</span>],
                  </div>
                  <div>
                    <span className="text-slate-500">learningCurrently:</span> [
                    <span className="text-indigo-600 dark:text-indigo-300">'Modern Web'</span>,{' '}
                    <span className="text-indigo-600 dark:text-indigo-300">'Firebase'</span>],
                  </div>
                  <div>
                    <span className="text-slate-500">workflow:</span>{' '}
                    <span className="text-cyan-600 dark:text-cyan-300">'AI-Assisted + Code Review'</span>
                  </div>
                </div>
                <div className="text-slate-500 dark:text-slate-500">&#125;;</div>
              </div>

              {/* Quick Project Snippet Banner */}
              <div className="mt-5 pt-4 border-t border-slate-200 dark:border-slate-800">
                <div className="flex items-center justify-between">
                  <div className="flex flex-col">
                    <span className="text-[11px] font-semibold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                      Featured Demo Website
                    </span>
                    <span className="text-xs sm:text-sm font-bold text-slate-800 dark:text-slate-100">
                      {FEATURED_PROJECT.title}
                    </span>
                  </div>
                  <a
                    id="hero-card-project-link"
                    href={FEATURED_PROJECT.liveUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs font-semibold px-2.5 py-1.5 rounded-lg bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 border border-sky-200 dark:border-sky-800 hover:bg-sky-100 transition-colors"
                  >
                    <span>View Demo</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
