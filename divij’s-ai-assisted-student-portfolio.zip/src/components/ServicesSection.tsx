import React from 'react';
import { 
  Building2, 
  UtensilsCrossed, 
  UserCheck, 
  Layout, 
  Smartphone, 
  PenTool, 
  Bot, 
  Sparkles,
  MessageSquare,
  ArrowRight
} from 'lucide-react';
import { SERVICES_DATA } from '../data/portfolioData';

export const ServicesSection: React.FC = () => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Building2':
        return <Building2 className="w-5 h-5 text-sky-500" />;
      case 'UtensilsCrossed':
        return <UtensilsCrossed className="w-5 h-5 text-amber-500" />;
      case 'UserCheck':
        return <UserCheck className="w-5 h-5 text-emerald-500" />;
      case 'Layout':
        return <Layout className="w-5 h-5 text-indigo-500" />;
      case 'Smartphone':
        return <Smartphone className="w-5 h-5 text-cyan-500" />;
      case 'PenTool':
        return <PenTool className="w-5 h-5 text-rose-500" />;
      case 'Bot':
        return <Bot className="w-5 h-5 text-violet-500" />;
      default:
        return <Layout className="w-5 h-5 text-sky-500" />;
    }
  };

  const scrollToContact = () => {
    const el = document.querySelector('#contact');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="services"
      className="py-16 sm:py-24 bg-slate-50 dark:bg-slate-950 border-b border-slate-200/80 dark:border-slate-800/80"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col items-center text-center mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 dark:bg-emerald-950/60 text-emerald-600 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-800 text-xs font-semibold uppercase tracking-wider mb-3">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Freelance Offerings</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            What I Can Build
          </h2>
          <p className="mt-3 text-sm sm:text-base text-slate-600 dark:text-slate-400 max-w-2xl">
            Custom, practical web solutions tailored for local businesses, creators, and professionals at student-friendly rates.
          </p>
        </div>

        {/* Services Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {SERVICES_DATA.map((service) => (
            <div
              key={service.id}
              id={`service-card-${service.id}`}
              className="group rounded-2xl bg-white dark:bg-slate-900 p-6 border border-slate-200 dark:border-slate-800 hover:border-sky-500/50 dark:hover:border-sky-500/50 hover:shadow-lg transition-all duration-300 flex flex-col justify-between"
            >
              <div>
                <div className="w-11 h-11 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  {getIcon(service.iconName)}
                </div>

                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2 group-hover:text-sky-600 dark:group-hover:text-sky-400 transition-colors">
                  {service.title}
                </h3>

                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed mb-4">
                  {service.description}
                </p>
              </div>

              <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs">
                <span className="text-slate-400 dark:text-slate-500 font-medium">Ideal for:</span>
                <span className="text-sky-600 dark:text-sky-400 font-semibold text-right">
                  {service.idealFor}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* Callout Banner */}
        <div
          id="services-cta-banner"
          className="mt-12 rounded-2xl bg-gradient-to-r from-sky-600 to-indigo-600 text-white p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-6 shadow-xl"
        >
          <div className="text-center sm:text-left">
            <h3 className="text-lg sm:text-xl font-bold mb-1">
              Need a website for your business?
            </h3>
            <p className="text-sky-100 text-xs sm:text-sm max-w-xl">
              Let's discuss your idea and bring a modern, responsive website to life for your brand.
            </p>
          </div>

          <button
            id="services-discuss-btn"
            onClick={scrollToContact}
            className="shrink-0 inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-white text-slate-900 hover:bg-slate-100 font-bold text-xs sm:text-sm shadow-md transition-all focus:outline-none focus:ring-2 focus:ring-white"
          >
            <MessageSquare className="w-4 h-4 text-sky-600" />
            <span>Let's Discuss Your Idea</span>
            <ArrowRight className="w-4 h-4 text-slate-900" />
          </button>
        </div>
      </div>
    </section>
  );
};
