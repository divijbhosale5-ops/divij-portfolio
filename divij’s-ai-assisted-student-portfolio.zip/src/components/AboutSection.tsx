import React from 'react';
import { BookOpen, Sparkles, Target, Code, Cpu, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

export const AboutSection: React.FC = () => {
  return (
    <section
      id="about"
      className="py-16 sm:py-24 bg-white dark:bg-slate-900/50 border-b border-slate-200/80 dark:border-slate-800/80"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col items-center text-center mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-50 dark:bg-sky-950/60 text-sky-600 dark:text-sky-400 border border-sky-200 dark:border-sky-800 text-xs font-semibold uppercase tracking-wider mb-3">
            <BookOpen className="w-3.5 h-3.5" />
            <span>About Me</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Student & Aspiring Web Developer
          </h2>
          <p className="mt-3 text-sm sm:text-base text-slate-600 dark:text-slate-400 max-w-2xl">
            Passionate about technology, web design, and delivering clean, affordable websites for small businesses.
          </p>
        </div>

        {/* Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Column: Narrative Story */}
          <div className="lg:col-span-7 space-y-5 text-slate-700 dark:text-slate-300 text-sm sm:text-base leading-relaxed">
            <div className="p-6 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200/80 dark:border-slate-800 space-y-4">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                <Target className="w-5 h-5 text-sky-500" />
                My Background & Learning Journey
              </h3>
              <p>
                Hello! I am <strong className="text-slate-900 dark:text-white font-semibold">Divij Nilkanth Bhosale</strong>, a student (10th pass) with a strong enthusiasm for computers and website development.
              </p>
              <p>
                During my studies, I have learned the core foundations of programming and web building, including <strong className="text-slate-900 dark:text-white font-semibold">HTML, CSS, and Python</strong>. I am fascinated by how a well-designed website can give local stores, restaurants, and startups a credible presence on the internet.
              </p>
              <p>
                Currently, I am actively expanding my skillset into <strong className="text-slate-900 dark:text-white font-semibold">modern web development, responsive website design, Firebase database integration, and website deployment</strong>.
              </p>
            </div>

            {/* AI-Assisted Development Explanation Card */}
            <div className="p-6 rounded-2xl bg-gradient-to-br from-indigo-50/70 to-sky-50/70 dark:from-slate-800/60 dark:to-indigo-950/30 border border-indigo-200/70 dark:border-indigo-800/50 space-y-3">
              <div className="flex items-center gap-2 text-indigo-700 dark:text-indigo-300 font-bold text-base">
                <Sparkles className="w-5 h-5" />
                <span>Honest Approach: AI-Assisted Web Development</span>
              </div>
              <p className="text-slate-700 dark:text-slate-300 text-sm sm:text-[15px] leading-relaxed">
                Rather than claiming everything is manually typed from scratch, I utilize modern AI coding tools to rapidly draft layouts, generate clean boilerplate, and structure pages.
              </p>
              <p className="text-slate-700 dark:text-slate-300 text-sm sm:text-[15px] leading-relaxed">
                I then personally review, test, customize, and refine every section of code to ensure it meets high standards of mobile responsiveness, visual polish, and performance. This modern workflow helps deliver websites much faster and at a student-friendly price for local businesses.
              </p>
            </div>
          </div>

          {/* Right Column: Key Principles & Highlights */}
          <div className="lg:col-span-5 space-y-4">
            {/* Mission Card */}
            <div className="p-5 sm:p-6 rounded-2xl bg-white dark:bg-slate-800/60 border border-slate-200 dark:border-slate-800 shadow-sm space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-sky-600 dark:text-sky-400">
                My Primary Goal
              </span>
              <h4 className="text-base font-bold text-slate-900 dark:text-white">
                Affordable & Modern Websites for Businesses
              </h4>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                To build useful, modern, and affordable websites for local businesses, shops, and individuals who want a great online presence without expensive agency fees.
              </p>
            </div>

            {/* Transparency Checklist */}
            <div className="p-5 sm:p-6 rounded-2xl bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 space-y-3">
              <span className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                What You Can Expect
              </span>
              <ul className="space-y-2.5 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                  <span>Honest communication about project timelines & capabilities</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                  <span>Clean mobile-friendly layouts tested on phones and laptops</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                  <span>Student-friendly pricing that fits small business budgets</span>
                </li>
                <li className="flex items-start gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                  <span>Dedicated effort to build and polish your website vision</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
