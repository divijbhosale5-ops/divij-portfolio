import React from 'react';
import { Smartphone, Sparkles, Zap, Tag, Shield } from 'lucide-react';
import { WHY_ME_DATA } from '../data/portfolioData';

export const WhyWorkWithMe: React.FC = () => {
  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Smartphone':
        return <Smartphone className="w-6 h-6 text-sky-500" />;
      case 'Sparkles':
        return <Sparkles className="w-6 h-6 text-indigo-500" />;
      case 'Zap':
        return <Zap className="w-6 h-6 text-amber-500" />;
      case 'Tag':
        return <Tag className="w-6 h-6 text-emerald-500" />;
      default:
        return <Sparkles className="w-6 h-6 text-sky-500" />;
    }
  };

  return (
    <section
      id="why-me"
      className="py-16 sm:py-24 bg-white dark:bg-slate-900/50 border-b border-slate-200/80 dark:border-slate-800/80"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col items-center text-center mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300 border border-cyan-200 dark:border-cyan-800 text-xs font-semibold uppercase tracking-wider mb-3">
            <Shield className="w-3.5 h-3.5" />
            <span>Value & Standards</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Why Work With Me
          </h2>
          <p className="mt-3 text-sm sm:text-base text-slate-600 dark:text-slate-400 max-w-2xl">
            A dedicated and transparent work ethic focused on building great websites that fit your budget and goals.
          </p>
        </div>

        {/* 4 Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {WHY_ME_DATA.map((item, idx) => (
            <div
              key={idx}
              id={`why-me-card-${idx}`}
              className="rounded-2xl bg-slate-50 dark:bg-slate-900 p-6 border border-slate-200 dark:border-slate-800 hover:border-sky-500/50 dark:hover:border-sky-500/50 transition-all duration-300 flex flex-col justify-between shadow-xs hover:shadow-md"
            >
              <div>
                <div className="w-12 h-12 rounded-xl bg-white dark:bg-slate-800 flex items-center justify-center mb-4 border border-slate-200/60 dark:border-slate-700/60 shadow-xs">
                  {getIcon(item.iconName)}
                </div>

                <h3 className="text-base sm:text-lg font-bold text-slate-900 dark:text-white mb-2">
                  {item.title}
                </h3>

                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                  {item.description}
                </p>
              </div>

              <div className="mt-6 pt-3 border-t border-slate-200/60 dark:border-slate-800/80 flex items-center text-[11px] font-semibold text-sky-600 dark:text-sky-400">
                <span>Committed to Quality</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
