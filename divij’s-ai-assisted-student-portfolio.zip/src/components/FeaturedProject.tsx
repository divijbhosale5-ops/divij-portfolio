import React, { useState } from 'react';
import { 
  ExternalLink, 
  Coffee, 
  Sparkles, 
  Smartphone, 
  Laptop, 
  UtensilsCrossed, 
  CheckCircle2,
  Clock,
  Layers,
  ArrowUpRight
} from 'lucide-react';
import { FEATURED_PROJECT } from '../data/portfolioData';

export const FeaturedProject: React.FC = () => {
  const [previewMode, setPreviewMode] = useState<'desktop' | 'mobile'>('desktop');

  return (
    <section
      id="projects"
      className="py-16 sm:py-24 bg-white dark:bg-slate-900/50 border-b border-slate-200/80 dark:border-slate-800/80"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col items-center text-center mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border border-amber-200 dark:border-amber-800 text-xs font-semibold uppercase tracking-wider mb-3">
            <Coffee className="w-3.5 h-3.5" />
            <span>Featured Portfolio Project</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Featured Work & Live Demo
          </h2>
          <p className="mt-3 text-sm sm:text-base text-slate-600 dark:text-slate-400 max-w-2xl">
            A practical web development showcase demonstrating how a modern café or restaurant website is built for mobile and desktop customers.
          </p>
        </div>

        {/* Featured Project Showcase Card */}
        <div
          id="featured-project-card"
          className="rounded-3xl bg-gradient-to-b from-slate-50 to-white dark:from-slate-900 dark:to-slate-950 border border-slate-200 dark:border-slate-800 p-6 sm:p-8 lg:p-10 shadow-xl"
        >
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center">
            {/* Left Column: Details & Tech */}
            <div className="lg:col-span-6 flex flex-col justify-between space-y-6">
              <div>
                {/* Demo Project Notice Badge */}
                <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 border border-sky-200 dark:border-sky-800 text-xs font-bold mb-4">
                  <span className="w-2 h-2 rounded-full bg-sky-500" />
                  <span>Café / Restaurant Demo Website</span>
                </div>

                <h3 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight mb-3">
                  {FEATURED_PROJECT.title}
                </h3>

                <p className="text-sm sm:text-base text-slate-600 dark:text-slate-300 leading-relaxed mb-6">
                  {FEATURED_PROJECT.description}
                </p>

                {/* Key Features Bullet Points */}
                <div className="space-y-3 mb-6">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    What This Demo Showcases
                  </h4>
                  <ul className="space-y-2.5">
                    {FEATURED_PROJECT.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
                        <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0 mt-0.5" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Technologies Used */}
                <div className="mb-6">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-2.5">
                    Technologies & Skills Used
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {FEATURED_PROJECT.technologies.map((tech) => (
                      <span
                        key={tech}
                        className="px-3 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 text-xs font-semibold border border-slate-200 dark:border-slate-700"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              {/* Action Link Button */}
              <div className="pt-4 border-t border-slate-200 dark:border-slate-800 flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                <a
                  id="view-live-website-btn"
                  href={FEATURED_PROJECT.liveUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-sm shadow-md shadow-sky-600/25 hover:shadow-lg transition-all focus:outline-none focus:ring-2 focus:ring-sky-500 group"
                >
                  <span>View Live Website</span>
                  <ExternalLink className="w-4 h-4 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-transform" />
                </a>

                <div className="text-center sm:text-left">
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
                    Opens live demo on Replit in a new tab
                  </span>
                </div>
              </div>
            </div>

            {/* Right Column: Visual Mockup & Interactive Visual Frame */}
            <div className="lg:col-span-6 w-full">
              <div className="relative rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-2xl">
                {/* Simulated Browser Bar */}
                <div className="bg-slate-800/90 px-4 py-3 border-b border-slate-700/80 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-rose-500" />
                    <div className="w-3 h-3 rounded-full bg-amber-500" />
                    <div className="w-3 h-3 rounded-full bg-emerald-500" />
                  </div>
                  <div className="flex-1 max-w-xs mx-3 bg-slate-900/80 px-3 py-1 rounded-md text-[11px] font-mono text-slate-400 truncate text-center border border-slate-700/50">
                    divijs-brew-bites.replit.app
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => setPreviewMode('desktop')}
                      className={`p-1 rounded ${previewMode === 'desktop' ? 'bg-sky-500/20 text-sky-400' : 'text-slate-400 hover:text-slate-200'}`}
                      title="Desktop preview mode"
                    >
                      <Laptop className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => setPreviewMode('mobile')}
                      className={`p-1 rounded ${previewMode === 'mobile' ? 'bg-sky-500/20 text-sky-400' : 'text-slate-400 hover:text-slate-200'}`}
                      title="Mobile preview mode"
                    >
                      <Smartphone className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Café Website Preview Graphical Canvas */}
                <div className={`p-5 transition-all duration-300 ${previewMode === 'mobile' ? 'max-w-[280px] mx-auto' : 'w-full'}`}>
                  <div className="rounded-xl overflow-hidden bg-stone-900 text-stone-100 border border-stone-800 shadow-inner">
                    {/* Simulated Café Header */}
                    <div className="bg-gradient-to-r from-amber-900/80 via-stone-900 to-amber-950/90 p-4 border-b border-amber-800/40">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <div className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400">
                            <Coffee className="w-4 h-4" />
                          </div>
                          <div>
                            <div className="font-serif font-bold text-sm text-amber-100">Divij's Brew & Bites</div>
                            <div className="text-[9px] text-amber-300/80 uppercase tracking-widest">Artisan Coffee & Kitchen</div>
                          </div>
                        </div>
                        <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-300 font-medium">
                          Demo Site
                        </span>
                      </div>
                      
                      <div className="text-center py-2">
                        <div className="text-xs font-serif italic text-amber-200">"Freshly Brewed Coffee & Warm Delights"</div>
                        <div className="text-[10px] text-stone-400 mt-1">Open Daily: 8:00 AM – 10:00 PM</div>
                      </div>
                    </div>

                    {/* Simulated Menu Highlights */}
                    <div className="p-4 space-y-3 bg-stone-950/90">
                      <div className="text-[11px] font-bold uppercase tracking-wider text-amber-400 border-b border-stone-800 pb-1 flex items-center justify-between">
                        <span>Featured Menu Items</span>
                        <UtensilsCrossed className="w-3.5 h-3.5 text-amber-500" />
                      </div>

                      <div className="grid grid-cols-2 gap-2 text-left">
                        <div className="p-2 rounded-lg bg-stone-900/80 border border-stone-800">
                          <div className="text-xs font-bold text-stone-200">Hazelnut Cappuccino</div>
                          <div className="text-[10px] text-stone-400">Espresso + Steamed Milk</div>
                          <div className="text-xs font-bold text-amber-400 mt-1">₹180</div>
                        </div>

                        <div className="p-2 rounded-lg bg-stone-900/80 border border-stone-800">
                          <div className="text-xs font-bold text-stone-200">Classic Club Sandwich</div>
                          <div className="text-[10px] text-stone-400">Grilled Cheese & Veggies</div>
                          <div className="text-xs font-bold text-amber-400 mt-1">₹220</div>
                        </div>

                        <div className="p-2 rounded-lg bg-stone-900/80 border border-stone-800">
                          <div className="text-xs font-bold text-stone-200">Caramel Frappuccino</div>
                          <div className="text-[10px] text-stone-400">Blended Cold Coffee</div>
                          <div className="text-xs font-bold text-amber-400 mt-1">₹210</div>
                        </div>

                        <div className="p-2 rounded-lg bg-stone-900/80 border border-stone-800">
                          <div className="text-xs font-bold text-stone-200">Warm Walnut Brownie</div>
                          <div className="text-[10px] text-stone-400">Served with Chocolate Dip</div>
                          <div className="text-xs font-bold text-amber-400 mt-1">₹160</div>
                        </div>
                      </div>

                      {/* Simulated Interactive Footer with Direct Launch */}
                      <div className="pt-2 text-center">
                        <a
                          href={FEATURED_PROJECT.liveUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1.5 text-xs font-bold text-amber-400 hover:text-amber-300 py-1"
                        >
                          <span>Explore Full Live Demo on Replit</span>
                          <ArrowUpRight className="w-3.5 h-3.5" />
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
