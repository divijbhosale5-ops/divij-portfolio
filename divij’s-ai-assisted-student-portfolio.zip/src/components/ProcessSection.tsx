import React from 'react';
import { Compass, MessageCircle, PenTool, Code2, Rocket, ArrowRight } from 'lucide-react';
import { PROCESS_STEPS } from '../data/portfolioData';

export const ProcessSection: React.FC = () => {
  const getStepIcon = (index: number) => {
    switch (index) {
      case 0:
        return <MessageCircle className="w-5 h-5 text-sky-500" />;
      case 1:
        return <PenTool className="w-5 h-5 text-indigo-500" />;
      case 2:
        return <Code2 className="w-5 h-5 text-emerald-500" />;
      case 3:
        return <Rocket className="w-5 h-5 text-amber-500" />;
      default:
        return <MessageCircle className="w-5 h-5 text-sky-500" />;
    }
  };

  return (
    <section
      id="process"
      className="py-16 sm:py-24 bg-slate-50 dark:bg-slate-950 border-b border-slate-200/80 dark:border-slate-800/80"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex flex-col items-center text-center mb-12 sm:mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-violet-50 dark:bg-violet-950/60 text-violet-700 dark:text-violet-300 border border-violet-200 dark:border-violet-800 text-xs font-semibold uppercase tracking-wider mb-3">
            <Compass className="w-3.5 h-3.5" />
            <span>How We Work</span>
          </div>
          <h2 className="text-2xl sm:text-4xl font-extrabold text-slate-900 dark:text-white tracking-tight">
            Simple 4-Step Process
          </h2>
          <p className="mt-3 text-sm sm:text-base text-slate-600 dark:text-slate-400 max-w-2xl">
            A structured, step-by-step approach to taking your website project from an initial idea to a live reality.
          </p>
        </div>

        {/* 4 Steps Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {PROCESS_STEPS.map((step, idx) => (
            <div
              key={step.step}
              id={`process-step-card-${step.step}`}
              className="relative rounded-2xl bg-white dark:bg-slate-900 p-6 border border-slate-200 dark:border-slate-800 flex flex-col justify-between hover:shadow-lg transition-all duration-300 group"
            >
              <div>
                {/* Step Number & Icon */}
                <div className="flex items-center justify-between mb-4">
                  <span className="font-mono text-2xl font-black text-slate-300 dark:text-slate-700 group-hover:text-sky-500 dark:group-hover:text-sky-400 transition-colors">
                    {step.step}
                  </span>
                  <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center">
                    {getStepIcon(idx)}
                  </div>
                </div>

                {/* Title */}
                <h3 className="text-lg font-bold text-slate-900 dark:text-white mb-2">
                  {step.title}
                </h3>

                {/* Primary Description */}
                <p className="text-xs sm:text-sm font-medium text-slate-700 dark:text-slate-300 mb-3">
                  {step.description}
                </p>

                {/* Extended Details */}
                <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                  {step.details}
                </p>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-[11px] font-semibold text-slate-400 dark:text-slate-500">
                <span>Phase {idx + 1} of 4</span>
                <ArrowRight className="w-3.5 h-3.5 text-sky-500 group-hover:translate-x-1 transition-transform" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
