import { ProjectItem, SkillItem, ServiceItem, ProcessStep, WhyMeItem } from '../types';

export const PERSONAL_INFO = {
  name: 'Divij Nilkanth Bhosale',
  shortName: 'Divij',
  title: 'Student & Aspiring Web Developer',
  badge: 'Available for Website Projects',
  heroSubtitle: 'Student | Aspiring Web Developer | AI-Assisted Website Developer',
  heroDescription: 'I create modern, responsive websites with the help of web technologies and AI-assisted development.',
  education: '10th Pass (Student)',
  phone: '7620084472',
  phoneFormatted: '+91 76200 84472',
  email: 'divijbhosale5@gmail.com',
  instagramHandle: '@customcraft_web',
  instagramUrl: 'https://www.instagram.com/customcraft_web/',
  whatsappUrl: 'https://wa.me/917620084472?text=Hi%20Divij%2C%20I%20am%20interested%20in%20discussing%20a%20website%20project%20for%20my%20business.',
  location: 'Maharashtra, India',
};

export const FEATURED_PROJECT: ProjectItem = {
  id: 'brew-and-bites',
  title: "Divij's Brew & Bites",
  badge: 'Featured Demo Project',
  isDemo: true,
  category: 'Café & Restaurant Demo Website',
  description: 'A café website demo created as a practical web development project, focused on a modern business website experience.',
  longDescription: 'Created as a complete demonstration of how a local café or restaurant can showcase its menu, special offers, atmosphere, and reservation information online. Built with a mobile-first focus to ensure customers browsing on smartphones get a fast, attractive experience.',
  liveUrl: 'https://divijs-brew-bites--divijbhosale06.replit.app/',
  technologies: ['HTML5', 'CSS3', 'Responsive Design', 'AI-Assisted Workflow', 'UI/UX Layout'],
  features: [
    'Interactive café menu preview with categories',
    'Mobile-first responsive layout tailored for smartphone diners',
    'Warm visual aesthetic suited for modern coffee shops & eateries',
    'Clear call-to-action sections for orders & visits'
  ]
};

export const SKILLS_DATA: SkillItem[] = [
  {
    name: 'HTML',
    category: 'Studied',
    level: 'Studied',
    description: 'Semantic page structuring, accessible elements, and solid web foundations.',
    iconName: 'Code'
  },
  {
    name: 'CSS',
    category: 'Studied',
    level: 'Studied',
    description: 'Styling, layout systems, flexbox, grid, and clean visual presentation.',
    iconName: 'Palette'
  },
  {
    name: 'Python',
    category: 'Studied',
    level: 'Studied',
    description: 'Core programming logic, basic scripting, and computational problem-solving.',
    iconName: 'Terminal'
  },
  {
    name: 'Responsive Web Design',
    category: 'Studied',
    level: 'Studied',
    description: 'Designing layouts that automatically adapt cleanly to mobile, tablet, and desktop screens.',
    iconName: 'Smartphone'
  },
  {
    name: 'AI-Assisted Development',
    category: 'Studied',
    level: 'Studied',
    description: 'Leveraging modern AI tools to accelerate building, followed by careful code review and testing.',
    iconName: 'Sparkles'
  },
  {
    name: 'Firebase',
    category: 'Currently Learning',
    level: 'Learning',
    description: 'Actively exploring database integration, backend hosting concepts, and cloud storage.',
    iconName: 'Database'
  },
  {
    name: 'Website Deployment',
    category: 'Currently Learning',
    level: 'Learning',
    description: 'Learning modern hosting platforms, domain connections, and live site publishing.',
    iconName: 'CloudUpload'
  }
];

export const SERVICES_DATA: ServiceItem[] = [
  {
    id: 'business-sites',
    title: 'Business Websites',
    description: 'Clean, professional web presence for local shops, services, and small enterprises looking to establish credibility online.',
    iconName: 'Building2',
    idealFor: 'Local businesses & service providers'
  },
  {
    id: 'cafe-restaurant',
    title: 'Café & Restaurant Websites',
    description: 'Appetizing, mobile-optimized websites featuring your food menu, location details, opening hours, and contact info.',
    iconName: 'UtensilsCrossed',
    idealFor: 'Coffee shops, diners & restaurants'
  },
  {
    id: 'portfolio-sites',
    title: 'Portfolio Websites',
    description: 'Personal and professional portfolio showcases designed to present your work, skills, and contact information with elegance.',
    iconName: 'UserCheck',
    idealFor: 'Students, creators & professionals'
  },
  {
    id: 'landing-pages',
    title: 'Landing Pages',
    description: 'High-focus, single-page sites dedicated to promoting a specific service, product launch, or marketing campaign.',
    iconName: 'Layout',
    idealFor: 'Marketing offers & new launches'
  },
  {
    id: 'responsive-mobile',
    title: 'Responsive Mobile Websites',
    description: 'Ensuring your website looks crisp and functions effortlessly on Android phones, iPhones, tablets, and desktops.',
    iconName: 'Smartphone',
    idealFor: 'Every modern website project'
  },
  {
    id: 'ui-design',
    title: 'Website UI Design',
    description: 'Modern, well-spaced visual interface layouts with clear hierarchy, readable typography, and intuitive navigation.',
    iconName: 'PenTool',
    idealFor: 'Visual branding & layout structure'
  },
  {
    id: 'ai-assisted-dev',
    title: 'AI-Assisted Website Development',
    description: 'Smart, efficient development utilizing AI tooling to accelerate delivery while keeping project pricing accessible.',
    iconName: 'Bot',
    idealFor: 'Fast turnaround & budget-friendly builds'
  }
];

export const WHY_ME_DATA: WhyMeItem[] = [
  {
    title: 'Mobile-Friendly Design',
    description: 'Over 80% of local visitors browse on phones. Every page is crafted to look sharp and load smoothly on all screen sizes.',
    iconName: 'Smartphone'
  },
  {
    title: 'Modern UI & Aesthetics',
    description: 'Clean layouts with balanced spacing, accessible typography, and thoughtful color schemes that make your business look professional.',
    iconName: 'Sparkles'
  },
  {
    title: 'AI-Assisted Development',
    description: 'Using AI-assisted workflows allows faster development turnaround and affordable costs, with manual verification of every component.',
    iconName: 'Zap'
  },
  {
    title: 'Student-Friendly Pricing',
    description: 'As an aspiring developer building my portfolio, I offer realistic, honest, and budget-friendly pricing tailored for small businesses.',
    iconName: 'Tag'
  }
];

export const PROCESS_STEPS: ProcessStep[] = [
  {
    step: '01',
    title: 'Discuss',
    description: "Understand the customer's business and requirements.",
    details: 'We talk about your business goals, target audience, required pages, colors, and content needs.'
  },
  {
    step: '02',
    title: 'Design',
    description: 'Plan the website structure and visual style.',
    details: 'Structuring the wireframe, choosing typography, organizing sections, and drafting the mobile-first layout.'
  },
  {
    step: '03',
    title: 'Build',
    description: 'Develop the website using web technologies and AI-assisted tools.',
    details: 'Writing clean code with HTML, CSS, and AI assistance, carefully reviewing and polishing every interaction.'
  },
  {
    step: '04',
    title: 'Launch',
    description: 'Test the website and help prepare it for deployment.',
    details: 'Testing across mobile and desktop devices, checking all links, and assisting with site hosting.'
  }
];
