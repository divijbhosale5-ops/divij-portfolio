export interface ProjectItem {
  id: string;
  title: string;
  badge: string;
  isDemo: boolean;
  category: string;
  description: string;
  longDescription: string;
  liveUrl: string;
  technologies: string[];
  features: string[];
}

export interface SkillItem {
  name: string;
  category: 'Studied' | 'Currently Learning';
  level: 'Studied' | 'Learning';
  description: string;
  iconName: string;
}

export interface ServiceItem {
  id: string;
  title: string;
  description: string;
  iconName: string;
  idealFor: string;
}

export interface ProcessStep {
  step: string;
  title: string;
  description: string;
  details: string;
}

export interface WhyMeItem {
  title: string;
  description: string;
  iconName: string;
}

export interface ContactFormData {
  name: string;
  email: string;
  phone: string;
  projectType: string;
  message: string;
}
